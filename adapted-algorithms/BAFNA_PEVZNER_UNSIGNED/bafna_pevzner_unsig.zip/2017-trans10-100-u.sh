#!/bin/bash

for ((number=10; number<=100; number=$number+10)); do
    file="/home/andre/perm-database/n$number.perm"
    for line in `cat $file`; do
        sorting=`python real_bafna_pevzner.py $line unsig/transp.n$number.dist unsig/transp/transp.n$number.sort`
    done
done
