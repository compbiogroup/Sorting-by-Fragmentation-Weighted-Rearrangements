#!/bin/bash

for ((number=1; number<=10; number=$number+1)); do
    file="/home/andre/dbk/n$number.perm"
    for line in `cat $file`; do
        sorting=`python unsigned_walter1998.py $line unsig/walter.n$number.dist unsig/walter.n$number.sort`
    done
done
